
# Cervus version 2.0

* Author: [XDeSIG][SITE]
* License: [Creative Commons BY-SA][CCBYSA]

![Render Cervus 2.0][RENDER]

[CCBYSA]: http://creativecommons.org/licenses/by-sa/4.0/
[SITE]: https://sites.google.com/site/xdesig/
[RENDER]: Cervus_2_0.jpg

