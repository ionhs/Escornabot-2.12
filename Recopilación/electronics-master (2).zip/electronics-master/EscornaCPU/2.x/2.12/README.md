# EscornaCPU 2.12 by XDesig

- [Escorna\_CPU\_2\_12\_Gerber.zip (Gerber files)][GER01]
- [Escorna\_CPU\_2\_12.brd (Eable Board)][BOA01]
- [Escorna\_CPU\_2\_12.sch (Eagle Schematics)][SCH01]
- [Escorna\_CPU\_2\_12\_ESQ.pdf (PDF Schematichs)][SCH02]
- [Escorna\_CPU\_2\_12\_measures.pdf (Board measures)][MEA01]
- [Caracteristicas\_CPU2\_12.pdf (in Galician)][NOT01]

![Top view](image1.png)
![Bottom view](image2.png)

[GER01]: Escorna_CPU_2_12_Gerber.zip
[BOA01]: Escorna_CPU_2_12.brd
[SCH01]: Escorna_CPU_2_12.sch
[SCH02]: Escorna_CPU_2_12_ESQ.pdf
[MEA01]: Escorna_CPU_2_12_measures.pdf
[NOT01]: Caracteristicas_CPU2_12.pdf

